﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication1
{
    public enum RgbColor
    {
        BLUE = 0,
        GREEN=1,
        RED=2
    }
}
